const { Client, LocalAuth } = require('whatsapp-web.js');
const TelegramBot = require('node-telegram-bot-api');
const qrcode = require('qrcode-terminal');
const fs = require('fs');

// === Replace this with your Telegram bot token ===
const TELEGRAM_TOKEN = 'YOUR_TELEGRAM_BOT_TOKEN';

if (TELEGRAM_TOKEN === 'YOUR_TELEGRAM_BOT_TOKEN') {
    console.log('❌ Please set your Telegram bot token in index.js');
    process.exit(1);
}

const bot = new TelegramBot(TELEGRAM_TOKEN, { polling: true });

bot.onText(/\/start/, async (msg) => {
    const chatId = msg.chat.id;
    const sessionId = String(chatId); // unique session per Telegram user

    const client = new Client({
        authStrategy: new LocalAuth({ clientId: sessionId }),
        puppeteer: {
            headless: true,
            args: ['--no-sandbox', '--disable-setuid-sandbox']
        }
    });

    client.on('qr', (qr) => {
        qrcode.generate(qr, { small: true });
        bot.sendMessage(chatId, '*Scan this QR Code with your WhatsApp:*', { parse_mode: 'Markdown' });
        bot.sendMessage(chatId, '```' + qr + '```', { parse_mode: 'Markdown' });
    });

    client.on('ready', () => {
        bot.sendMessage(chatId, '✅ WhatsApp connected successfully!');
    });

    client.on('auth_failure', () => {
        bot.sendMessage(chatId, '❌ Authentication failed. Please try again.');
    });

    client.on('disconnected', () => {
        bot.sendMessage(chatId, '🔌 WhatsApp disconnected.');
    });

    client.initialize();
});
