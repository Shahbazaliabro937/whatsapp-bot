# WhatsApp Telegram Bot

A simple bot to bridge WhatsApp and Telegram messages.